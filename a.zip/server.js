const awsServerlessExpress = require('aws-serverless-express');
const express = require('express');
const bodyParser = require('body-parser');
const cors = require('cors');
const db = require('./db');

const app = express();
app.use(bodyParser.json());
app.use(cors()); // Enable CORS for frontend calls

// ✅ Health check route
app.get('/health', (req, res) => {
  res.status(200).json({ status: 'OK' });
});

// ✅ Get all todos
app.get('/todos', async (req, res) => {
  try {
    const todos = await db.getTodos();
    res.json(todos);
  } catch (error) {
    console.error('Error fetching todos:', error);
    res.status(500).json({ error: 'Error fetching todos' });
  }
});

// ✅ Add a new todo
app.post('/add-todo', async (req, res) => {
  const { task } = req.body;

  if (!task || task.trim() === '') {
    return res.status(400).json({ error: 'Task is required' });
  }

  try {
    await db.addTodo(task);
    res.status(201).json({ message: 'Todo added successfully' });
  } catch (error) {
    console.error('Error adding todo:', error);
    res.status(500).json({ error: 'Error adding todo' });
  }
});

// ✅ Delete a todo by ID
app.delete('/delete-todo/:id', async (req, res) => {
  const { id } = req.params;

  if (!id) {
    return res.status(400).json({ error: 'Todo ID is required' });
  }

  try {
    const result = await db.deleteTodo(id);

    if (result.affectedRows === 0) {
      return res.status(404).json({ error: 'Todo not found' });
    }

    res.status(200).json({ message: 'Todo deleted successfully' });
  } catch (error) {
    console.error('Error deleting todo:', error);
    res.status(500).json({ error: 'Error deleting todo' });
  }
});

// ✅ Create the serverless express server
const server = awsServerlessExpress.createServer(app);

// ✅ Export Lambda handler
exports.handler = (event, context) => {
  return awsServerlessExpress.proxy(server, event, context);
};
